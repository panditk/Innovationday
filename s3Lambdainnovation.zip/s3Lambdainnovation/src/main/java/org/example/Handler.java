
package org.example;

import software.amazon.awssdk.services.s3.model.*;
import software.amazon.awssdk.services.s3.S3Client;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.lambda.runtime.events.models.s3.S3EventNotification.S3EventNotificationRecord;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Handler implements RequestHandler<S3Event, String> {
    private static final Logger logger = LoggerFactory.getLogger(Handler.class);
    @Override
    public String handleRequest(S3Event s3event, Context context) {

        System.out.println("RequestHandler:handleRequest");
        try {
            S3EventNotificationRecord record = s3event.getRecords().get(0);
            System.out.println("record " + record);
            String srcBucket = record.getS3().getBucket().getName();
            System.out.println("srcBucket" +srcBucket);
            String srcKey = record.getS3().getObject().getUrlDecodedKey();
            System.out.println("srcKey" +srcKey);

            S3Client s3Client = S3Client.builder().build();
            HeadObjectResponse headObject = getHeadObject(s3Client, srcBucket, srcKey);
            System.out.println("Successfully retrieved " + srcBucket + "/" + srcKey + " of type " + headObject.contentType());
            String toBucket = "pandit.fileupload";

            //TODO :Antivirus scan

            copyBucketObject(s3Client, srcBucket, srcKey, toBucket);
        } catch (Exception e) {

            System.out.println( e.getMessage());
            throw new RuntimeException(e);
        }
        return "Ok";
    }

    private HeadObjectResponse getHeadObject(S3Client s3Client, String bucket, String key) {
        HeadObjectRequest headObjectRequest = HeadObjectRequest.builder()
                .bucket(bucket)
                .key(key)
                .build();
        return s3Client.headObject(headObjectRequest);
    }

    public static String copyBucketObject(S3Client s3, String fromBucket, String objectKey, String toBucket) {
        CopyObjectRequest copyReq = CopyObjectRequest.builder()
                .sourceBucket(fromBucket)
                .sourceKey(objectKey)
                .destinationBucket(toBucket)
                .destinationKey(objectKey)
                .build();

        try {
            CopyObjectResponse copyRes = s3.copyObject(copyReq);
            return copyRes.copyObjectResult().toString();

        } catch (S3Exception e) {
            System.err.println(e.awsErrorDetails().errorMessage());
            System.exit(1);
        }
        return "";
    }
}
